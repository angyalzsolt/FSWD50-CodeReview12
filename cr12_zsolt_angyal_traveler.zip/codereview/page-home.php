<?php get_header(); ?>

<div class="row">

	<div class="col-sm-12">
		
	



		
<div id="newtheme-carousel" class="carousel slide" data-ride="carousel">



  <div class="carousel-inner">

  		<?php

		$args_cat = array(
			'include' => '13, 14, 15'
		);

		$categories = get_categories($args_cat);
		$count = 0;
		$bullets = '';
		foreach ($categories as $category):
					$args = array(
				'type' => 'post',
				'posts_per_page' => 1,
				'category__in' => $category->term_id,
				'category__not_in' => array(16),
			);

			$lastBlog = new WP_Query($args);

		if( $lastBlog->have_posts() ):

			
			
			while( $lastBlog->have_posts() ): $lastBlog-> the_post(); ?>

	<div class="carousel-item <?php if($count == 0): echo 'active'; endif; ?>">

      		<?php the_post_thumbnail('large') ?>
      		<div class="carousel-caption d-none d-md-block">	
      			<?php the_title(sprintf('<h1 class="blog-title"><a href="%s">', esc_url(get_permalink() ) ), '</a></h1>'); ?>

	<small><?php the_category() ?></small>
    		</div>
  	</div>

  	 <?php $bullets .= '<li data-target="#newtheme-carousel" data-slide-to="'.$count.'" class="'; ?>
						    <?php if($count == 0): $bullets .='active'; endif; ?>
						    
						    <?php  $bullets .= '"></li>'; ?>

			
			<?php  endwhile;
			
		endif;

		wp_reset_postdata();

		$count++;

		endforeach;

		

		 ?>
		
  <ol class="carousel-indicators">
    
  </ol>




  <a class="carousel-control-prev" href="#newtheme-carousel" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#newtheme-carousel" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>


</div>
</div>
<!--===============================================-->
</div>
	<div class="row">
		<div class="col-xs-12 col-sm-8">


 	<?php 
	
		if( have_posts() ):
		
		while( have_posts() ): the_post(); ?>
		


		<h1>Welcome to the page</h1>

			<small>Posted on: <?php the_time('F j, Y'); ?> at <?php the_time('g:i a'); ?>, in <?php the_category(); ?></small>
			
			<p><?php the_content(); ?></p>
			
			<hr>
		
		<?php endwhile;
		
	endif;

/*	//print other posts	
	$args = array(
		'type' => 'post',
		'post_per_page' => 2,
		'offset' => 1,
	);

		$lastBlog = new WP_Query($args);
	if( $lastBlog->have_posts() ):
		
		while( $lastBlog->have_posts() ): $lastBlog-> the_post(); ?>



			<?php get_template_part('content', get_post_format()); ?>
		
			
		
		<?php endwhile;
		
	endif;

	wp_reset_postdata();
	*/		
	?>


	<?php 

	//print tutorials
/*
		$lastBlog = new WP_Query('type=post&posts_per_page=-1&category_name=news');
	if( $lastBlog->have_posts() ):
		
		while( $lastBlog->have_posts() ): $lastBlog-> the_post(); ?>



			<?php get_template_part('content', get_post_format()); ?>
		
			
		
		<?php endwhile;
		
	endif;

	wp_reset_postdata();
*/

	 ?>


	</div>

	<div class="col-xs-12 col-sm-4">
		<?php get_sidebar(); ?>
	</div>
</div>


 <?php get_footer(); ?>
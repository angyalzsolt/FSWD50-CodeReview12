<!DOCTYPE html>
<html>
<head>
	<title>CodeReview12</title>
	<meta charset="utf-8">
	<?php wp_head(); ?>
	<style>
		.menu-item {
			margin: 0 5px;
		}

		.carousel .carousel-item {
			height: 350px;
			overflow: hidden;
		}
		.carousel .carousel-item img {
			width: 100%;
			height: auto;
		}

		.thumbnail {
			width: 100%;
		}

		.thumbnail img {
			width: 100%;
		}

		ul, li {
  			list-style-type: none;
		}

		article {
			overflow: hidden;
		}

		#img {
			padding: 5px;
		}

		#passt {
			padding:  5px;
		}
	</style>
</head>


<?php
 if(is_front_page()):
 	$codereview_classes = array('newtheme-class', 'my-class');
else:
	$codereview_classes = array( 'not-newtheme-class');
 	endif;
?>

<body <?php body_class($codereview_classes)?>>

	<div class="container">
		<div class="row">
			<div class="col-sm-12">


					<nav class="navbar navbar-expand-lg navbar-light bg-light">
					  <a class="navbar-brand" href="#">CodeReview12</a>
					  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
					    <span class="navbar-toggler-icon"></span>
					  </button>

					  <div class="collapse navbar-collapse" id="navbarSupportedContent">
					
					  	<?php wp_nav_menu(array(
					  				'theme_location' => 'primary',
					  				'container' => false,
					  				'menu_class' => 'navbar-nav mr-auto',
					  ));?> 


 						
				 		<li class="nav-item dropdown">
					        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					          Show
					        </a>
					        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
					         
					  	<?php wp_nav_menu(array(
					  				'theme_location' => 'primary',
					  				'container' => true,
					  				'menu_class' => 'dropdown-item',
					  ));?> 


					        </div>
				      </li>
					  	<!--
					    <ul class="navbar-nav mr-auto">
					      <li class="nav-item active">
					        <a class="nav-link" href="#">Home <span class="sr-only"></span></a>
					      </li>
					      <li class="nav-item">
					        <a class="nav-link" href="#">Link</a>
					      </li>
					    </ul>-->
					 </div>
					</nav>


				
			</div>
		</div>

	
	<?php 
//var_dump(get_custom_header());
	 ?>



	 

	<!--<img src="<?php header_image(); ?>" height="<?php echo get_custom_header()->height; ?>" width="<?php echo get_custom_header()->width; ?>" alt="" />-->


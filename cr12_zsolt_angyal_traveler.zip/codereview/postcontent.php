<article class="col-md-6 col-lg-12" id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	
	<header class="blog-header">
		<?php the_title(sprintf('<h1 class="blog-title"><a href="%s">',esc_url(get_permalink())),'</a></h1>'); ?>
		<small>Posted on: <?php the_time('F j, Y'); ?> at <?php the_time('g:i a'); ?>, in <?php the_category(); ?></small>
	</header>
	
	<div id"passt" class="row">
		<?php if( has_post_thumbnail() ): ?>
		<div id="img" class="col-md-12">
			<div class="thumbnail"><?php the_post_thumbnail('large	') ?></div>
		</div class="col-md-12">
		<div>
			<?php the_content(); ?>
		</div>
	<?php else: ?>

		<div class="col-md-12">
			<?php the_content(); ?>
		</div>
	<?php endif; ?>

	</div>

	
	
				
	
</article>			

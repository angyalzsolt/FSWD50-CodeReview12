	<hr>
	<footer>
		<p>CodeReview12</p>
		<?php wp_nav_menu(array('theme_location'=>'secondary')); ?>
	</footer>

	</div>
	
	<?php wp_footer() ?>
	</body>
</html>
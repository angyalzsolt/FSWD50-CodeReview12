<?php get_header(); ?>



<div class="row">
	<div class="container">
  <div class="jumbotron">
    <h1>Blog posts...</h1> 
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent fringilla elit dolor, eu interdum eros cursus vitae. Aliquam ultricies eu dolor at maximus. Integer vitae accumsan felis, eget aliquam nisl.</p> 
  </div>
</div>

	
	<div class="col-xs-12 col-sm-12">

		<div class="row">
			
		
 	<?php 
	
	if( have_posts() ):
		
		while( have_posts() ): the_post(); ?>



			<?php get_template_part('content', get_post_format()); ?>
		
			
		
		<?php endwhile;
		
	endif;
			
	?>
	</div>
</div>
	
</div>

 <?php get_footer(); ?>